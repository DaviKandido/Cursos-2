import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ListEmployess } from "./employees/list-employess";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ListEmployess],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'AngularCrud';
}
